export * from './ReactNativeSVG';

export { default } from './ReactNativeSVG';
