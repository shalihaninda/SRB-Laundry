export function parse(transform: string, options?: object): number[];
