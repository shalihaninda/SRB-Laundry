export const units: { objectBoundingBox: number; userSpaceOnUse: number } = {
  objectBoundingBox: 0,
  userSpaceOnUse: 1,
};
export default units;
