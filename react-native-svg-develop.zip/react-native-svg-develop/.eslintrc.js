module.exports = {
  extends: '@react-native-community',
  rules: { 'no-bitwise': 0, '@typescript-eslint/no-explicit-any': 2 },
};
